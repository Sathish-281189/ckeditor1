/**
 * CKEditorModule
 */
export declare class CKEditorModule {
}
