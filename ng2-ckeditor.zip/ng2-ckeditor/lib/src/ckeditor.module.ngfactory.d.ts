import * as i0 from '@angular/core';
import * as i1 from './ckeditor.module';
export declare const CKEditorModuleNgFactory: i0.NgModuleFactory<i1.CKEditorModule>;
